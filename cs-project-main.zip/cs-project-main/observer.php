<?php 
interface iobserver
{
     function update(tripnotify $obj);
}
?>