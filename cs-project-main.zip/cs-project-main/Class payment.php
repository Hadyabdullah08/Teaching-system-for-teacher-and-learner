<?php
//stratgy pattern
interface ipayment
{
	public function pay();
}
?>