<?php
interface  itripnotify
{
    function  attach($obj);
    function notifyall();
}
?>