<?php
include_once "sub.php";
abstract class obs
{
    protected subject $u;
    public abstract function update();
}
?>